export const testimonials = [
  {
    id: 1,
    name: 'Sarah L.',
    quote: "These are hands-down the best cookies I've ever had. The Strawberry Shortcake Bliss is a game-changer! So fresh and flavorful.",
    location: 'New York, NY',
  },
  {
    id: 2,
    name: 'Mike R.',
    quote: "I'm a chocolate chip purist, and Crumble Creations nailed it. It's the perfect balance of chewy and crispy. My weekly treat!",
    location: 'Austin, TX',
  },
  {
    id: 3,
    name: 'Jessica P.',
    quote: "The custom order for my son's birthday was a huge hit! The design was perfect, and they tasted even better. Amazing service.",
    location: 'Chicago, IL',
  },
];
